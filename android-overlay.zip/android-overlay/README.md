# Ethiopian Calendar Overlay — Android App

A native Android app that displays a floating widget near the status bar showing the current Ethiopian month (Amharic script) and day in Roman numerals.

---

## Get the APK via GitHub Actions (No Android Studio needed)

1. **Create a free GitHub account** at github.com if you don't have one

2. **Create a new repository** — go to github.com/new, name it `ethiopian-calendar`, set it to Public, click Create

3. **Upload this folder**
   - On the new repo page click **"uploading an existing file"**
   - Drag the entire `android-overlay` folder contents in
   - Click **Commit changes**

4. **Watch it build**
   - Click the **Actions** tab — you'll see "Build Ethiopian Calendar APK" running
   - Wait ~3 minutes for it to finish (green checkmark)

5. **Download your APK**
   - Click the completed workflow run
   - Scroll to **Artifacts** at the bottom
   - Click **EthiopianCalendar-debug** to download the APK zip
   - Unzip it — inside is `app-debug.apk`

6. **Install on your phone**
   - Send the APK to your phone (email, Google Drive, WhatsApp, etc.)
   - On your Android phone: Settings → Apps → Special app access → Install unknown apps → enable for your browser/files app
   - Tap the APK file to install

7. **Use the overlay**
   - Open the app → tap **Grant** → enable "Display over other apps"
   - Tap **Start Overlay**
   - The `መጋቢት · XVIII` widget appears near your status bar, draggable, always on top

---

## Project Structure

```
android-overlay/
├── app/src/main/
│   ├── AndroidManifest.xml          — permissions (SYSTEM_ALERT_WINDOW)
│   └── java/com/ethiopian/calendar/
│       ├── EthiopianCalendar.kt     — conversion logic + Roman numerals
│       ├── OverlayService.kt        — floating widget over all apps
│       └── MainActivity.kt          — permission flow + Compose UI
└── .github/workflows/build-apk.yml — auto-builds the APK on GitHub
```
