package com.ethiopian.calendar

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.util.Calendar

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private val CHANNEL_ID = "eth_overlay_channel"

    private val updateTask = object : Runnable {
        override fun run() {
            updateOverlay()
            // Schedule next update at the start of the next minute
            val now = Calendar.getInstance()
            val delay = (60 - now.get(Calendar.SECOND)) * 1000L
            handler.postDelayed(this, delay)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(1, buildNotification())
        createOverlay()
        handler.post(updateTask)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(updateTask)
        overlayView?.let { windowManager.removeView(it) }
    }

    // ── Overlay View ───────────────────────────────────────────────────────────

    private fun createOverlay() {
        val layout = buildOverlayLayout()

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16   // right margin in px (dp handled below)
            y = statusBarHeight() + dpToPx(6)
        }

        // Make draggable
        var startX = 0f; var startY = 0f; var startRawX = 0; var startRawY = 0
        layout.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x.toFloat()
                    startY = params.y.toFloat()
                    startRawX = event.rawX.toInt()
                    startRawY = event.rawY.toInt()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX - (event.rawX - startRawX)).toInt()
                    params.y = (startY + (event.rawY - startRawY)).toInt()
                    windowManager.updateViewLayout(v, params)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(layout, params)
        overlayView = layout
    }

    private fun buildOverlayLayout(): LinearLayout {
        val eth = EthiopianCalendar.today()
        val roman = EthiopianCalendar.toRoman(eth.day)

        // Container
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundResource(0)
            setPadding(dpToPx(6), dpToPx(3), dpToPx(6), dpToPx(3))
        }

        // Pill background
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = pillBackground()
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            gravity = Gravity.CENTER_VERTICAL
        }

        // Month text (Amharic / Ethiopic)
        val monthView = TextView(this).apply {
            text = eth.monthName
            setTextColor(Color.parseColor("#C8973A"))   // amber
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = 0f
        }

        // Divider
        val divider = View(this).apply {
            setBackgroundColor(Color.parseColor("#44FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(dpToPx(1), dpToPx(14)).also {
                it.setMargins(dpToPx(6), 0, dpToPx(6), 0)
            }
        }

        // Roman numeral day
        val romanView = TextView(this).apply {
            text = roman
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.SERIF
            letterSpacing = 0.05f
        }

        pill.addView(monthView)
        pill.addView(divider)
        pill.addView(romanView)
        container.addView(pill)

        return container
    }

    private fun updateOverlay() {
        val eth = EthiopianCalendar.today()
        val roman = EthiopianCalendar.toRoman(eth.day)

        val layout = overlayView as? LinearLayout ?: return
        val pill = layout.getChildAt(0) as? LinearLayout ?: return
        val monthView = pill.getChildAt(0) as? TextView ?: return
        val romanView = pill.getChildAt(2) as? TextView ?: return

        monthView.text = eth.monthName
        romanView.text = roman

        // Also update the foreground notification
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotification())
    }

    // ── Notification (required for foreground service) ─────────────────────────

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Ethiopian Calendar Overlay",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Keeps the Ethiopian date overlay running"
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val eth = EthiopianCalendar.today()
        val roman = EthiopianCalendar.toRoman(eth.day)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("${eth.monthName}  ·  $roman")
            .setContentText("Ethiopian Calendar — ${eth.year} E.C.")
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun pillBackground(): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(20).toFloat()
            setColor(Color.parseColor("#CC1A1A2E"))   // semi-transparent deep indigo
            setStroke(dpToPx(1), Color.parseColor("#33C8973A"))
        }
    }

    private fun statusBarHeight(): Int {
        val resourceId = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) resources.getDimensionPixelSize(resourceId) else dpToPx(24)
    }

    private fun dpToPx(dp: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp.toFloat(), resources.displayMetrics).toInt()
}
