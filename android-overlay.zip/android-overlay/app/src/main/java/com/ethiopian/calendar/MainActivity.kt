package com.ethiopian.calendar

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.Manifest

class MainActivity : ComponentActivity() {

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { checkAndLaunch() }

    private val notifPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { checkAndLaunch() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            EthiopianCalendarTheme {
                MainScreen(
                    onGrantOverlay = { requestOverlayPermission() },
                    onToggleService = { toggleService() },
                    isServiceRunning = isServiceRunning()
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Refresh UI state when returning from permission screens
        setContent {
            EthiopianCalendarTheme {
                MainScreen(
                    onGrantOverlay = { requestOverlayPermission() },
                    onToggleService = { toggleService() },
                    isServiceRunning = isServiceRunning()
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            checkAndLaunch()
        }
    }

    private fun checkAndLaunch() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                return
            }
        }
        if (Settings.canDrawOverlays(this)) {
            startOverlayService()
        }
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopOverlayService() {
        stopService(Intent(this, OverlayService::class.java))
    }

    private fun toggleService() {
        if (isServiceRunning()) stopOverlayService() else checkAndLaunch()
    }

    private fun isServiceRunning(): Boolean {
        val manager = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        @Suppress("DEPRECATION")
        return manager.getRunningServices(Int.MAX_VALUE)
            .any { it.service.className == OverlayService::class.java.name }
    }
}

// ── UI ─────────────────────────────────────────────────────────────────────────

@Composable
fun EthiopianCalendarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF0F1117),
            surface = Color(0xFF161A27),
            primary = Color(0xFFC8973A),
            onBackground = Color(0xFFF5EFE0),
            onSurface = Color(0xFFF5EFE0),
        ),
        content = content
    )
}

@Composable
fun MainScreen(
    onGrantOverlay: () -> Unit,
    onToggleService: () -> Unit,
    isServiceRunning: Boolean
) {
    val eth = remember { EthiopianCalendar.today() }
    val roman = remember { EthiopianCalendar.toRoman(eth.day) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F1117))
            .windowInsetsPadding(WindowInsets.systemBars),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(28.dp)
        ) {

            // Title
            Text(
                text = "የኢትዮጵያ ቀን\nመቁጠሪያ",
                color = Color(0xFFC8973A),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 38.sp
            )
            Text(
                text = "Ethiopian Calendar Overlay",
                color = Color(0xFF9A9080),
                fontSize = 13.sp,
                letterSpacing = 0.5.sp
            )

            Spacer(Modifier.height(4.dp))

            // Live date card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFF161A27))
                    .border(1.dp, Color(0xFF2A2E42), RoundedCornerShape(20.dp))
                    .padding(vertical = 28.dp, horizontal = 24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("MONTH", color = Color(0xFF9A9080), fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(eth.monthName, color = Color(0xFFC8973A), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text("${eth.year} E.C.", color = Color(0xFF9A9080), fontSize = 11.sp)
                    }
                    Box(
                        Modifier
                            .width(1.dp)
                            .height(60.dp)
                            .background(Color(0xFF2A2E42))
                    )
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("DAY", color = Color(0xFF9A9080), fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(roman, color = Color(0xFFF5EFE0), fontSize = 26.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif)
                        Spacer(Modifier.height(4.dp))
                        Text("${eth.day}", color = Color(0xFF9A9080), fontSize = 11.sp)
                    }
                }
            }

            // Step indicators
            PermissionStep(
                number = "1",
                title = "Grant Overlay Permission",
                description = "Allows drawing the widget over the status bar area",
                onGrantOverlay = onGrantOverlay
            )

            // Toggle button
            Button(
                onClick = onToggleService,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isServiceRunning) Color(0xFF2A2E42) else Color(0xFFC8973A)
                )
            ) {
                Text(
                    text = if (isServiceRunning) "Stop Overlay" else "Start Overlay",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFF5EFE0)
                )
            }

            if (isServiceRunning) {
                Text(
                    text = "Overlay is active — look for the widget near your status bar",
                    color = Color(0xFF9A9080),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun PermissionStep(
    number: String,
    title: String,
    description: String,
    onGrantOverlay: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF161A27))
            .border(1.dp, Color(0xFF2A2E42), RoundedCornerShape(14.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color(0xFFC8973A)),
            contentAlignment = Alignment.Center
        ) {
            Text(number, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = Color(0xFFF5EFE0), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(description, color = Color(0xFF9A9080), fontSize = 11.sp, lineHeight = 16.sp)
        }
        TextButton(onClick = onGrantOverlay) {
            Text("Grant", color = Color(0xFFC8973A), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
