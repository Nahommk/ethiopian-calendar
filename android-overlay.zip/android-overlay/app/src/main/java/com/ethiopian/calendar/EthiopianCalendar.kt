package com.ethiopian.calendar

import java.util.Calendar

object EthiopianCalendar {

    val AMHARIC_MONTHS = arrayOf(
        "መስከረም", "ጥቅምት", "ህዳር", "ታህሳስ",
        "ጥር",     "የካቲት", "መጋቢት", "ሚያዝያ",
        "ግንቦት",   "ሰኔ",   "ሃምሌ",  "ነሃሴ",  "ጳጉሜ"
    )

    val AMHARIC_MONTHS_SHORT = arrayOf(
        "መስ", "ጥቅ", "ህዳ", "ታህ",
        "ጥር", "የካ", "መጋ", "ሚያ",
        "ግን", "ሰኔ", "ሃም", "ነሃ", "ጳጉ"
    )

    data class EthDate(val year: Int, val month: Int, val day: Int) {
        val monthName: String get() = AMHARIC_MONTHS.getOrElse(month - 1) { "ጳጉሜ" }
        val monthNameShort: String get() = AMHARIC_MONTHS_SHORT.getOrElse(month - 1) { "ጳጉ" }
    }

    fun today(): EthDate {
        val cal = Calendar.getInstance()
        return fromGregorian(
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH) + 1,
            cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    fun fromGregorian(y: Int, m: Int, d: Int): EthDate {
        return jdnToEthiopian(gregorianToJdn(y, m, d))
    }

    private fun gregorianToJdn(y: Int, m: Int, d: Int): Long {
        val a = (14 - m) / 12
        val yr = y + 4800 - a
        val mo = m + 12 * a - 3
        return d + (153L * mo + 2) / 5 + 365L * yr + yr / 4 - yr / 100 + yr / 400 - 32045
    }

    private fun jdnToEthiopian(jdn: Long): EthDate {
        val r = ((jdn - 1723856) % 1461).toInt()
        val n = (r % 365) + 365 * (r / 1460)
        val year = 4 * ((jdn - 1723856) / 1461).toInt() + r / 365 - r / 1460
        val month = (n / 30) + 1
        val day = (n % 30) + 1
        return EthDate(year, month.coerceAtMost(13), day)
    }

    fun toRoman(num: Int): String {
        if (num <= 0 || num > 3999) return "—"
        val values  = intArrayOf(1000,900,500,400,100,90,50,40,10,9,5,4,1)
        val symbols = arrayOf("M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I")
        val sb = StringBuilder()
        var n = num
        for (i in values.indices) {
            while (n >= values[i]) { sb.append(symbols[i]); n -= values[i] }
        }
        return sb.toString()
    }
}
